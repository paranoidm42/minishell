#include <stdio.h>
#include <readline/readline.h>
#include <sys/ioctl.h>
#include <signal.h>
#include "mini.h"
#include "libft/libft.h"
char	*find_path(char **env)
{
	int	i = 0;
	while(env[i])
	{
		if (ft_strncmp(env[i],"PATH=",5) == 0)
			break;
		i++;
	}
	return (ft_substr(env[i],5,ft_strlen(env[i])));
}
char	*get_path(t_mini *data, char **env,char *cmd)
{
	char	*path = find_path(env);
	char	**splitted_path = ft_split(path,':');
	char	**splitted_cmd = ft_split(cmd,' ');
	int	i = 0;
	char *sub;
	char *join;
	while(splitted_path[i])
	{
		sub = ft_strjoin(splitted_path[i],"/");
		join = ft_strjoin(sub,*splitted_cmd);
		if (!access(join,F_OK))
			break;
		free(sub);
		free(join);
		i++;
	}
	return (join);
}
void	execute_one(t_mini *data,char **env)
{
	char	*path;
	int	pid;
	pid = fork();
	if (pid == -1)
		perror("pid");
	else if (pid == 0)
	{
		path = get_path(data,env,data->cmd[0]);
		execve(path,data->cmd,env);
	}
	waitpid(-1,NULL,0);
}

void	sig_int(int sig)
{
	(void)sig;
	ioctl(STDIN_FILENO, TIOCSTI, "\n");
	rl_replace_line("", 0);
	rl_on_new_line();
}

void	ft_signal(int flag)
{
	if (flag == 1)
	{
		signal(SIGINT, sig_int);
		signal(SIGQUIT, SIG_IGN);
	}
	else if (flag == 3)
	{
		exit(0);
	}
}

int main(int ac, char **av, char **env)
{
	t_mini *data;

	data = (t_mini *)malloc(sizeof(t_mini));
	if(!data)
		return (0);
	if (ac != 1 || av[1])
		return (0);
	int	i = 0;
	while (env[i])
	{
		printf("%s\n", env[i]);
		i++;
	}
	while (1)
	{
		ft_signal(1);
		data->line = readline("bshell>");
		if (!data->line)
			ft_signal(3);
		data->cmd = ft_split(data->line,' ');
		execute_one(data,env);
		waitpid(-1,NULL,0);
	}
}
