#ifndef MINI_H
#define MINI_H


typedef struct s_mini
{
	char	*line;
	char	**cmd;
	int		fd[2];
}				t_mini;

#endif